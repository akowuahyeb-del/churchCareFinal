// screens/ClaimAccountScreen.js
//
// Reached from a "I have a Member ID" link on the Login/Welcome screen.
// Two steps: (1) verify the Member ID + phone against an existing member
// record, (2) create a Firebase Auth account and link it to that record.
//
// No admin session needed — this is the self-service counterpart to
// InviteMemberScreen, for someone who got their code via WhatsApp, a
// printed QR code, or verbally from an admin.

import React, { useState } from "react";
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  Alert, SafeAreaView, StatusBar, ActivityIndicator, KeyboardAvoidingView, Platform
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { createUserWithEmailAndPassword } from "firebase/auth";
import { auth } from "../firebase";
import { verifyMemberCode, completeMemberClaim } from "../utils/memberIntake";

export default function ClaimAccountScreen({ navigation }) {
  const [step, setStep] = useState("code"); // "code" | "account"
  const [memberCode, setMemberCode] = useState("");
  const [phone, setPhone] = useState("");
  const [verified, setVerified] = useState(null); // { claimToken, memberName, organizationId, entityId }
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  const handleVerify = async () => {
    if (!memberCode.trim() || !phone.trim()) {
      Alert.alert("Required", "Enter your Member ID and phone number");
      return;
    }
    setBusy(true);
    try {
      const result = await verifyMemberCode({ memberCode: memberCode.trim(), phone: phone.trim() });

      if (!result.valid) {
        const messages = {
          not_found: "We couldn't find that Member ID. Double-check it and try again.",
          already_registered: "This Member ID is already linked to an account — try logging in instead.",
          phone_mismatch: "That phone number doesn't match our records for this Member ID.",
        };
        Alert.alert("Couldn't verify", messages[result.reason] || "Something didn't match. Please try again.");
        return;
      }

      setVerified(result);
      setStep("account");
    } catch (e) {
      Alert.alert("Error", e.message);
    } finally {
      setBusy(false);
    }
  };

  const handleCreateAccount = async () => {
    if (!email.trim() || password.length < 6) {
      Alert.alert("Required", "Enter a valid email and a password of at least 6 characters");
      return;
    }
    setBusy(true);
    try {
      await createUserWithEmailAndPassword(auth, email.trim(), password);
      // auth.currentUser is now set — completeMemberClaim reads request.auth server-side.
      const result = await completeMemberClaim({ claimToken: verified.claimToken });

      await AsyncStorage.setItem("isLoggedIn", "true");
      await AsyncStorage.setItem("activeEntity", JSON.stringify({
        organizationId: result.organizationId,
        entityId: result.entityId,
        name: result.entityName || "Church",
      }));

      Alert.alert("Welcome!", "Your account is set up.", [
        { text: "Continue", onPress: () => navigation.replace("MainTabs") },
      ]);
    } catch (e) {
      console.log("CLAIM ACCOUNT ERROR:", e);
      Alert.alert("Couldn't create account", e.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <KeyboardAvoidingView style={styles.safe} behavior={Platform.OS === "ios" ? "padding" : undefined}>
      <SafeAreaView style={{ flex: 1 }}>
        <StatusBar barStyle="light-content" backgroundColor="#4B3F72" />
        <View style={styles.header}>
          <Ionicons name="id-card-outline" size={36} color="#fff" />
          <Text style={styles.headerTitle}>
            {step === "code" ? "Enter your Member ID" : "Create your account"}
          </Text>
          <Text style={styles.headerSub}>
            {step === "code"
              ? "Your church admin sent this to you, or you can scan the QR they shared."
              : `Almost done, ${verified?.memberName?.split(" ")[0] || "there"}!`}
          </Text>
        </View>

        <View style={styles.body}>
          {step === "code" ? (
            <>
              <Text style={styles.label}>Member ID</Text>
              <TextInput
                style={styles.input}
                value={memberCode}
                onChangeText={setMemberCode}
                placeholder="e.g. CH-LOC-123-45"
                autoCapitalize="characters"
              />
              <Text style={styles.label}>Phone Number</Text>
              <TextInput
                style={styles.input}
                value={phone}
                onChangeText={setPhone}
                placeholder="The number your church has on file"
                keyboardType="phone-pad"
              />
              <TouchableOpacity style={[styles.btn, busy && { opacity: 0.6 }]} onPress={handleVerify} disabled={busy}>
                {busy ? <ActivityIndicator color="#fff" /> : <Text style={styles.btnText}>Verify</Text>}
              </TouchableOpacity>
            </>
          ) : (
            <>
              <Text style={styles.label}>Email</Text>
              <TextInput
                style={styles.input}
                value={email}
                onChangeText={setEmail}
                placeholder="your@email.com"
                autoCapitalize="none"
                keyboardType="email-address"
              />
              <Text style={styles.label}>Password</Text>
              <TextInput
                style={styles.input}
                value={password}
                onChangeText={setPassword}
                placeholder="At least 6 characters"
                secureTextEntry
              />
              <TouchableOpacity style={[styles.btn, busy && { opacity: 0.6 }]} onPress={handleCreateAccount} disabled={busy}>
                {busy ? <ActivityIndicator color="#fff" /> : <Text style={styles.btnText}>Create Account</Text>}
              </TouchableOpacity>
              <TouchableOpacity onPress={() => setStep("code")} style={{ alignItems: "center", padding: 10 }}>
                <Text style={{ color: "#888" }}>Back</Text>
              </TouchableOpacity>
            </>
          )}
        </View>
      </SafeAreaView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#4B3F72" },
  header: { alignItems: "center", paddingTop: 30, paddingBottom: 24, paddingHorizontal: 24 },
  headerTitle: { fontSize: 18, fontWeight: "800", color: "#fff", marginTop: 10, textAlign: "center" },
  headerSub: { fontSize: 12, color: "rgba(255,255,255,0.75)", marginTop: 6, textAlign: "center" },
  body: { flex: 1, backgroundColor: "#fff", borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 20, paddingTop: 24 },
  label: { fontSize: 11, fontWeight: "700", color: "#888", textTransform: "uppercase", marginTop: 14, marginBottom: 6 },
  input: { backgroundColor: "#f5f5f5", borderRadius: 10, padding: 12, fontSize: 14, color: "#222", borderWidth: 1.5, borderColor: "#eee" },
  btn: { backgroundColor: "#4B3F72", borderRadius: 12, padding: 15, alignItems: "center", marginTop: 20 },
  btnText: { color: "#fff", fontWeight: "800", fontSize: 14 },
});
