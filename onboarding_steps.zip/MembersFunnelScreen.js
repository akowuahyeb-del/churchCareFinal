// screens/MembersFunnelScreen.js
//
// Admin-facing dashboard: how many members are at each lifecycle stage,
// and where they came from (QR / manual / bulk upload).

import React, { useEffect, useState, useCallback } from "react";
import {
  View, Text, StyleSheet, ScrollView, RefreshControl,
  SafeAreaView, StatusBar, ActivityIndicator
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import AsyncStorage from "@react-native-async-storage/async-storage";
import AppHeader from "../components/AppHeader";
import { getFunnelStats } from "../utils/memberIntake";

const STAGE_META = [
  { key: "visitor",          label: "Visitor",          color: "#4B3F72", icon: "footsteps-outline" },
  { key: "interested",       label: "Interested",       color: "#4B3F72", icon: "heart-circle-outline" },
  { key: "pending_approval", label: "Pending approval", color: "#D97706", icon: "hourglass-outline" },
  { key: "member",           label: "Member",           color: "#00B894", icon: "checkmark-circle-outline" },
  { key: "invited",          label: "Invited",          color: "#0984E3", icon: "mail-outline" },
  { key: "registered",       label: "Registered",       color: "#0984E3", icon: "person-add-outline" },
  { key: "active_user",      label: "Active user",      color: "#6C5CE7", icon: "flash-outline" },
];

const SOURCE_META = [
  { key: "qr_attendance", label: "QR check-in" },
  { key: "qr_register",   label: "QR registration" },
  { key: "manual",        label: "Manual add" },
  { key: "bulk_upload",   label: "Bulk upload" },
];

export default function MembersFunnelScreen({ navigation }) {
  const [activeEntity, setActiveEntity] = useState(null);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    AsyncStorage.getItem("activeEntity").then(raw => {
      if (raw) setActiveEntity(JSON.parse(raw));
    });
  }, []);

  const load = useCallback(async () => {
    if (!activeEntity?.organizationId || !activeEntity?.entityId) return;
    try {
      const data = await getFunnelStats({
        organizationId: activeEntity.organizationId,
        entityId: activeEntity.entityId,
      });
      setStats(data);
    } catch (e) {
      console.log("FUNNEL STATS ERROR:", e);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [activeEntity]);

  useEffect(() => { load(); }, [load]);

  const onRefresh = () => { setRefreshing(true); load(); };

  const totalInFunnel = stats
    ? STAGE_META.reduce((sum, s) => sum + (stats.counts?.[s.key] || 0), 0)
    : 0;

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" backgroundColor="#4B3F72" />
      <AppHeader title="Onboarding Funnel" subtitle="Where members are in the pipeline" onBack={() => navigation.goBack()} />

      {loading ? (
        <View style={styles.center}><ActivityIndicator color="#4B3F72" size="large" /></View>
      ) : (
        <ScrollView
          style={styles.body}
          contentContainerStyle={{ padding: 14, paddingBottom: 40 }}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#4B3F72" />}
        >
          <Text style={styles.sectionHeader}>By stage</Text>
          <View style={styles.card}>
            {STAGE_META.map(stage => {
              const count = stats?.counts?.[stage.key] || 0;
              const pct = totalInFunnel > 0 ? Math.round((count / totalInFunnel) * 100) : 0;
              return (
                <View key={stage.key} style={styles.row}>
                  <View style={[styles.icon, { backgroundColor: stage.color + "18" }]}>
                    <Ionicons name={stage.icon} size={16} color={stage.color} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.rowLabel}>{stage.label}</Text>
                    <View style={styles.barTrack}>
                      <View style={[styles.barFill, { width: `${pct}%`, backgroundColor: stage.color }]} />
                    </View>
                  </View>
                  <Text style={styles.rowCount}>{count}</Text>
                </View>
              );
            })}
          </View>

          <Text style={styles.sectionHeader}>By source</Text>
          <View style={styles.card}>
            {SOURCE_META.map(src => (
              <View key={src.key} style={styles.row}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.rowLabel}>{src.label}</Text>
                </View>
                <Text style={styles.rowCount}>{stats?.bySource?.[src.key] || 0}</Text>
              </View>
            ))}
          </View>

          <Text style={styles.hint}>
            Pull down to refresh. Stage thresholds for follow-up nudges are configured
            server-side in the onboarding Cloud Function.
          </Text>
        </ScrollView>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#4B3F72" },
  body: { flex: 1, backgroundColor: "#f4f6fb" },
  center: { flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: "#f4f6fb" },
  sectionHeader: { fontSize: 11, fontWeight: "800", color: "#aaa", textTransform: "uppercase", letterSpacing: 0.8, marginTop: 10, marginBottom: 8 },
  card: { backgroundColor: "#fff", borderRadius: 14, padding: 6, elevation: 1 },
  row: { flexDirection: "row", alignItems: "center", paddingHorizontal: 8, paddingVertical: 10, gap: 10 },
  icon: { width: 32, height: 32, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  rowLabel: { fontSize: 13, fontWeight: "700", color: "#222", marginBottom: 4 },
  rowCount: { fontSize: 15, fontWeight: "800", color: "#222", minWidth: 30, textAlign: "right" },
  barTrack: { height: 6, backgroundColor: "#f0f0f0", borderRadius: 3, overflow: "hidden" },
  barFill: { height: 6, borderRadius: 3 },
  hint: { fontSize: 11, color: "#aaa", textAlign: "center", marginTop: 16, lineHeight: 16, paddingHorizontal: 10 },
});
