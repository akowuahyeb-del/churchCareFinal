# Member onboarding lifecycle — schema & setup

## Assumptions made (adjust if wrong)
- Members live at `organizations/{organizationId}/entities/{entityId}/members/{memberId}`
  (matches the path pattern already used for `events` and `contributions` in SettingsScreen).
- You're on Firebase Functions v2 syntax (`onSchedule`, `onCall`, `onDocumentUpdated`).
- No push/SMS/email provider is wired up yet — `sendNotification()` in `onboarding.js`
  is written to degrade gracefully (logs + no-ops) until you plug in real credentials.
  Recommended: Expo push notifications (you're already on Expo) for in-app nudges,
  Twilio for SMS, and either SendGrid or your existing email provider.

## Member document shape

```js
{
  name: string,
  phone: string | null,
  email: string | null,

  // ── Membership qualification track ──
  // "visitor" | "interested" | "pending_approval" | "member"
  // ── App account track (only after "member") ──
  // "invited" | "registered" | "active_user"
  lifecycleStatus: string,
  lastStageChangeAt: Timestamp,       // used by the stage watcher to detect staleness
  lastChangedByUid: string | null,    // set by client right before writing lifecycleStatus;
                                       // the onDocumentUpdated trigger reads this into
                                       // statusHistory then clears it — keeps history
                                       // logging server-side and tamper-resistant
  statusHistory: [
    { status: string, changedAt: Timestamp, changedByUid: string | null, note: string | null }
  ],

  source: "qr_attendance" | "qr_register" | "manual" | "bulk_upload",
  assignedAdminUid: string | null,    // who gets the "follow up" nudge

  // Invite (app account) fields
  inviteToken: string | null,
  inviteChannel: "push" | "sms" | "email" | null,
  inviteSentAt: Timestamp | null,
  inviteRetryCount: number,

  // Set once they complete signup
  uid: string | null,
  lastLoginAt: Timestamp | null,
  expoPushToken: string | null,

  // Duplicate handling
  duplicateOf: string | null,         // memberId this record was merged into, if any

  createdAt: Timestamp,
  updatedAt: Timestamp,
}
```

## Required Firestore indexes
`collectionGroup: members` — composite index on `(lifecycleStatus ASC, lastStageChangeAt ASC)`.
Firestore will prompt you with a direct link to create this the first time the
scheduled function runs and the query fails — just click it.

## Deploy checklist
1. Copy `functions/onboarding.js` into your functions project, add it to your `index.js` exports.
2. `npm install expo-server-sdk twilio nodemailer` (or drop whichever channels you won't use).
3. Set config: `firebase functions:config:set twilio.sid=... twilio.token=... twilio.from=...`
   (same pattern for email). Until set, `sendNotification` just logs and returns — nothing breaks.
4. Deploy: `firebase deploy --only functions:onboarding`
5. Wire `utils/memberIntake.js` into your manual-add form, bulk upload loop, and QR landing screen.
6. Call `markActiveUser` right after a successful login in `LoginScreen.js` / `PinEntryScreen.js`.
